/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package khuselekasecurities;

import javax.swing.JMenuBar;


/**
 *
 * @author Sinesipho
 */
public class KhuselekaSecurities {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       frmLogin frmM = new frmLogin();
       frmM.show();
             
         
    }

    String mEncrypt(String toUpperCase, int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    String mDecrypt(String toUpperCase, int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
