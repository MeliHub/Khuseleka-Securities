/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package khuselekasecurities;

import javax.swing.JMenuBar;


/**
 *
 * @author Sinesipho
 */
public class KhuselekaSecurities {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       frmMain frmM = new frmMain();
       frmM.show();
       
       
         javax.swing.JMenu mnuVisitorsJMenu = new javax.swing.JMenu("Visitors");
        
         
    }
    
}
